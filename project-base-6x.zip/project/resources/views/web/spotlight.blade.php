@extends('web.master.master')

@section('content')
    <h2 class="text-center p-5 text-front">Seja bem vindo aos nosso <b>EMPREENDIMENTO</b> de <b>DESTAQUE!</b></h2>
@endsection