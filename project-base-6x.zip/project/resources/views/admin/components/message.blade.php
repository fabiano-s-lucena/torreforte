<div class="message message-{{ $color }}">
    {{ $slot }}
</div>